## Motivation

To find difference between two long json files on the cli itself, instead of downloading files and copy pasting on some website to find the difference. Helpful when comparing production env data with the admin dashboard data during the debugging process.

## Usage

<video width="320" height="240" controls>
    <source src="visuals/jdif_cli.mp4" type="video/mp4">
</video>


![alt text](visuals/jdif_cli.png)